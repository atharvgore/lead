"""
train_model.py

Trains the XGBoost lead scoring model on sample_leads.csv and saves it
to models/lead_scoring_model.joblib.

Usage:
    python scripts/train_model.py
"""

import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

import pandas as pd

from src.lead_scoring import LeadScoringModel

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "sample_leads.csv")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
MODEL_PATH = os.path.join(MODEL_DIR, "lead_scoring_model.joblib")


def main():
    df = pd.read_csv(DATA_PATH)

    model = LeadScoringModel()
    model.train(df, label_col="converted")

    os.makedirs(MODEL_DIR, exist_ok=True)
    model.save(MODEL_PATH)
    print(f"Model trained on {len(df)} rows and saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()
