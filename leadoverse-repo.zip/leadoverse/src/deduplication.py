"""
deduplication.py

Fuzzy + exact-match deduplication for lead records.

Composite similarity score:
    S = w1 * sim_email + w2 * sim_phone + w3 * sim_name
    w1 = 0.5, w2 = 0.3, w3 = 0.2

If S >= 0.85, the two records are considered duplicates.
"""

from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import List, Tuple

DUPLICATE_THRESHOLD = 0.85
WEIGHTS = {"email": 0.5, "phone": 0.3, "name": 0.2}


@dataclass
class Lead:
    id: str
    name: str
    email: str
    phone: str


def _levenshtein_ratio(a: str, b: str) -> float:
    """Similarity ratio in [0, 1]. Uses difflib as a dependency-free stand-in
    for Levenshtein distance; swap in python-Levenshtein for large volumes."""
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower().strip(), b.lower().strip()).ratio()


def _exact_match(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return 1.0 if a.strip().lower() == b.strip().lower() else 0.0


def similarity(lead_a: Lead, lead_b: Lead) -> float:
    sim_email = _exact_match(lead_a.email, lead_b.email)
    sim_phone = _exact_match(lead_a.phone, lead_b.phone)
    sim_name = _levenshtein_ratio(lead_a.name, lead_b.name)

    return (
        WEIGHTS["email"] * sim_email
        + WEIGHTS["phone"] * sim_phone
        + WEIGHTS["name"] * sim_name
    )


def find_duplicates(leads: List[Lead]) -> List[Tuple[Lead, Lead, float]]:
    """Returns all pairs of leads whose similarity score exceeds the threshold."""
    duplicates = []
    for i in range(len(leads)):
        for j in range(i + 1, len(leads)):
            score = similarity(leads[i], leads[j])
            if score >= DUPLICATE_THRESHOLD:
                duplicates.append((leads[i], leads[j], round(score, 3)))
    return duplicates


def deduplicate(leads: List[Lead]) -> List[Lead]:
    """Returns a deduplicated list, keeping the first-seen record of each cluster."""
    kept: List[Lead] = []
    for lead in leads:
        if not any(similarity(lead, existing) >= DUPLICATE_THRESHOLD for existing in kept):
            kept.append(lead)
    return kept
