"""
lead_scoring.py

XGBoost-based lead scoring. Combines demographic, firmographic, behavioral,
and intent-classification features into a single 0-100 quality score.

Score >= 70  ->  Sales Qualified Lead (SQL)
"""

from dataclasses import dataclass
from typing import Optional

import joblib
import numpy as np
import pandas as pd
from xgboost import XGBClassifier

SQL_THRESHOLD = 70

FEATURE_COLUMNS = [
    "company_size",
    "email_opens",
    "page_visits",
    "content_downloads",
    "engagement_velocity",
    "intent_score",  # 0/1/2 for Low/Medium/High, from intent_detection.py
]


@dataclass
class LeadScoreResult:
    score: int
    is_sql: bool
    features_used: dict


class LeadScoringModel:
    """Thin wrapper around an XGBoost classifier for lead quality scoring."""

    def __init__(self, model_path: Optional[str] = None):
        self.model: XGBClassifier = (
            joblib.load(model_path) if model_path else XGBClassifier(
                n_estimators=200,
                max_depth=4,
                learning_rate=0.08,
                eval_metric="logloss",
            )
        )

    def train(self, df: pd.DataFrame, label_col: str = "converted"):
        """Train on historical lead data. `df` must contain FEATURE_COLUMNS + label_col."""
        X = df[FEATURE_COLUMNS]
        y = df[label_col]
        self.model.fit(X, y)
        return self

    def save(self, path: str):
        joblib.dump(self.model, path)

    def score_lead(self, features: dict) -> LeadScoreResult:
        """Score a single lead. `features` must contain all FEATURE_COLUMNS."""
        row = pd.DataFrame([{col: features.get(col, 0) for col in FEATURE_COLUMNS}])
        proba = self.model.predict_proba(row)[0][1]  # P(converts)
        score = int(round(proba * 100))
        return LeadScoreResult(
            score=score,
            is_sql=score >= SQL_THRESHOLD,
            features_used=row.iloc[0].to_dict(),
        )


def intent_to_numeric(intent_label: str) -> int:
    """Map BERT intent classification output to a numeric feature."""
    mapping = {"low": 0, "medium": 1, "high": 2}
    return mapping.get(intent_label.lower(), 0)
