"""
crm_sync.py

Adapters for pushing Sales Qualified Leads (SQL, score >= 70) to connected
CRM platforms. Each adapter implements the same `push_lead` interface so the
pipeline doesn't need to know which CRM is active.

These are stub implementations — plug in real API credentials and endpoints
before using against a live CRM.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict


@dataclass
class CRMLead:
    lead_id: str
    name: str
    email: str
    phone: str
    score: int
    intent: str


class CRMAdapter(ABC):
    @abstractmethod
    def push_lead(self, lead: CRMLead) -> Dict:
        ...


class SalesforceAdapter(CRMAdapter):
    def __init__(self, api_token: str = ""):
        self.api_token = api_token

    def push_lead(self, lead: CRMLead) -> Dict:
        # Replace with a real call to Salesforce's REST API, e.g.
        # POST /services/data/vXX.0/sobjects/Lead
        return {"crm": "salesforce", "status": "synced", "lead_id": lead.lead_id}


class HubSpotAdapter(CRMAdapter):
    def __init__(self, api_key: str = ""):
        self.api_key = api_key

    def push_lead(self, lead: CRMLead) -> Dict:
        # Replace with a real call to HubSpot's Contacts API.
        return {"crm": "hubspot", "status": "synced", "lead_id": lead.lead_id}


class ZohoAdapter(CRMAdapter):
    def __init__(self, api_key: str = ""):
        self.api_key = api_key

    def push_lead(self, lead: CRMLead) -> Dict:
        # Replace with a real call to Zoho CRM's Leads API.
        return {"crm": "zoho", "status": "synced", "lead_id": lead.lead_id}


CRM_REGISTRY = {
    "salesforce": SalesforceAdapter,
    "hubspot": HubSpotAdapter,
    "zoho": ZohoAdapter,
}


def sync_qualified_lead(lead: CRMLead, crm_name: str, **adapter_kwargs) -> Dict:
    adapter_cls = CRM_REGISTRY.get(crm_name.lower())
    if not adapter_cls:
        raise ValueError(f"Unknown CRM: {crm_name}")
    adapter = adapter_cls(**adapter_kwargs)
    return adapter.push_lead(lead)
