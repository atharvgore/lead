"""
pipeline.py

The hybrid pipeline: takes a raw lead, runs deduplication, intent
classification, and scoring, and returns a single consolidated result.
This mirrors the "Hybrid ML Classifier" described in the paper — a
weighted ensemble that aggregates signals from each module rather than
relying on any one score in isolation.
"""

from dataclasses import dataclass
from typing import List, Optional

from .deduplication import Lead, deduplicate
from .intent_detection import IntentDetector
from .lead_scoring import LeadScoringModel, intent_to_numeric


@dataclass
class PipelineResult:
    lead_id: str
    score: int
    is_sql: bool
    intent: str
    intent_confidence: float


class LeadPipeline:
    def __init__(self, scoring_model: LeadScoringModel, intent_detector: Optional[IntentDetector] = None):
        self.scoring_model = scoring_model
        self.intent_detector = intent_detector or IntentDetector(use_transformer=False)

    def process(self, lead: Lead, interaction_text: str, behavioral_features: dict) -> PipelineResult:
        intent_result = self.intent_detector.classify(interaction_text)

        features = {
            **behavioral_features,
            "intent_score": intent_to_numeric(intent_result.label),
        }
        score_result = self.scoring_model.score_lead(features)

        return PipelineResult(
            lead_id=lead.id,
            score=score_result.score,
            is_sql=score_result.is_sql,
            intent=intent_result.label,
            intent_confidence=intent_result.confidence,
        )

    def process_batch(self, leads: List[Lead], texts: List[str], features: List[dict]) -> List[PipelineResult]:
        deduped = deduplicate(leads)
        deduped_ids = {l.id for l in deduped}
        results = []
        for lead, text, feat in zip(leads, texts, features):
            if lead.id not in deduped_ids:
                continue
            results.append(self.process(lead, text, feat))
        return results
