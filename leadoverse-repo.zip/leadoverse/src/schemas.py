"""
schemas.py

Pydantic models for request/response validation in the FastAPI app.
"""

from pydantic import BaseModel, Field


class LeadInput(BaseModel):
    name: str
    email: str
    phone: str
    interaction_text: str = Field(
        ..., description="Raw text from the lead's interaction, e.g. a form message or chat log."
    )
    company_size: int = 0
    email_opens: int = 0
    page_visits: int = 0
    content_downloads: int = 0
    engagement_velocity: float = 0.0


class LeadScoreResponse(BaseModel):
    score: int
    is_sql: bool
    intent: str
    intent_confidence: float
    duplicate_of: str | None = None
