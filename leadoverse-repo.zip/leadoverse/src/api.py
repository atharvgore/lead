"""
api.py

FastAPI application exposing the Leadoverse scoring pipeline.

Run with:
    uvicorn src.api:app --reload
"""

import uuid

from fastapi import FastAPI

from .deduplication import Lead
from .intent_detection import IntentDetector
from .lead_scoring import LeadScoringModel
from .pipeline import LeadPipeline
from .schemas import LeadInput, LeadScoreResponse

app = FastAPI(
    title="Leadoverse API",
    description="AI-powered multi-channel lead scoring and management.",
    version="1.0.0",
)

# In production, load a trained model from disk via LeadScoringModel(model_path=...)
scoring_model = LeadScoringModel()
pipeline = LeadPipeline(scoring_model=scoring_model, intent_detector=IntentDetector(use_transformer=False))


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/score-lead", response_model=LeadScoreResponse)
def score_lead(payload: LeadInput):
    lead = Lead(
        id=str(uuid.uuid4()),
        name=payload.name,
        email=payload.email,
        phone=payload.phone,
    )

    behavioral_features = {
        "company_size": payload.company_size,
        "email_opens": payload.email_opens,
        "page_visits": payload.page_visits,
        "content_downloads": payload.content_downloads,
        "engagement_velocity": payload.engagement_velocity,
    }

    result = pipeline.process(lead, payload.interaction_text, behavioral_features)

    return LeadScoreResponse(
        score=result.score,
        is_sql=result.is_sql,
        intent=result.intent,
        intent_confidence=result.intent_confidence,
    )
