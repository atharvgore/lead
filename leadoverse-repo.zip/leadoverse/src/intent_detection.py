"""
intent_detection.py

Classifies buying intent (High / Medium / Low) from lead interaction text
using a Hugging Face transformer pipeline.

Swap MODEL_NAME for a model fine-tuned on your own lead interaction data.
Falls back to a lightweight keyword heuristic if transformers isn't
available, so the rest of the pipeline can still be exercised locally.
"""

from dataclasses import dataclass
from typing import List

MODEL_NAME = "distilbert-base-uncased-finetuned-sst-2-english"

HIGH_INTENT_KEYWORDS = ["pricing", "demo", "buy", "quote", "contract", "purchase"]
MEDIUM_INTENT_KEYWORDS = ["compare", "features", "case study", "trial", "how does"]


@dataclass
class IntentResult:
    label: str  # "High" | "Medium" | "Low"
    confidence: float


class IntentDetector:
    def __init__(self, use_transformer: bool = True):
        self.use_transformer = use_transformer
        self._pipeline = None
        if use_transformer:
            try:
                from transformers import pipeline
                self._pipeline = pipeline("sentiment-analysis", model=MODEL_NAME)
            except Exception:
                # Transformers/model not available in this environment —
                # fall back to the keyword heuristic below.
                self.use_transformer = False

    def classify(self, text: str) -> IntentResult:
        text_lower = text.lower()

        if self.use_transformer and self._pipeline:
            result = self._pipeline(text)[0]
            # Map sentiment confidence into a rough intent proxy.
            # In production this should be a model fine-tuned directly
            # on labeled lead-intent data rather than generic sentiment.
            score = result["score"]
            if any(k in text_lower for k in HIGH_INTENT_KEYWORDS):
                return IntentResult("High", max(score, 0.75))
            if any(k in text_lower for k in MEDIUM_INTENT_KEYWORDS):
                return IntentResult("Medium", max(score, 0.5))
            return IntentResult("Low", score)

        # Heuristic fallback
        if any(k in text_lower for k in HIGH_INTENT_KEYWORDS):
            return IntentResult("High", 0.8)
        if any(k in text_lower for k in MEDIUM_INTENT_KEYWORDS):
            return IntentResult("Medium", 0.55)
        return IntentResult("Low", 0.3)

    def classify_batch(self, texts: List[str]) -> List[IntentResult]:
        return [self.classify(t) for t in texts]
