import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from src.deduplication import Lead, deduplicate, find_duplicates, similarity


def test_matching_email_and_phone_is_duplicate():
    # Per the paper's weights (email 0.5, phone 0.3, name 0.2), email alone
    # can't cross the 0.85 threshold — duplicates need at least two fields
    # to agree. This mirrors that intentionally.
    a = Lead(id="1", name="Ravi Sharma", email="ravi@example.com", phone="9000000000")
    b = Lead(id="2", name="Ravi S.", email="ravi@example.com", phone="9000000000")
    assert similarity(a, b) >= 0.85


def test_email_match_alone_is_not_enough():
    a = Lead(id="1", name="Ravi Sharma", email="ravi@example.com", phone="9000000000")
    b = Lead(id="2", name="Someone Else", email="ravi@example.com", phone="9111111111")
    assert similarity(a, b) < 0.85


def test_different_leads_are_not_duplicates():
    a = Lead(id="1", name="Ravi Sharma", email="ravi@example.com", phone="9000000000")
    b = Lead(id="2", name="Priya Nair", email="priya@example.com", phone="9111111111")
    assert similarity(a, b) < 0.85


def test_deduplicate_keeps_first_seen():
    leads = [
        Lead(id="1", name="Ravi Sharma", email="ravi@example.com", phone="9000000000"),
        Lead(id="2", name="Ravi Sharma", email="ravi@example.com", phone="9000000000"),
        Lead(id="3", name="Priya Nair", email="priya@example.com", phone="9111111111"),
    ]
    result = deduplicate(leads)
    assert len(result) == 2
    assert result[0].id == "1"


def test_find_duplicates_returns_pairs():
    leads = [
        Lead(id="1", name="Ravi Sharma", email="ravi@example.com", phone="9000000000"),
        Lead(id="2", name="Ravi Sharma", email="ravi@example.com", phone="9000000000"),
    ]
    dupes = find_duplicates(leads)
    assert len(dupes) == 1
