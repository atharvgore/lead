import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

import pandas as pd

from src.lead_scoring import LeadScoringModel, intent_to_numeric

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "sample_leads.csv")


def test_intent_to_numeric_mapping():
    assert intent_to_numeric("High") == 2
    assert intent_to_numeric("Medium") == 1
    assert intent_to_numeric("Low") == 0
    assert intent_to_numeric("unknown") == 0


def test_model_trains_and_scores():
    df = pd.read_csv(DATA_PATH)
    model = LeadScoringModel()
    model.train(df, label_col="converted")

    result = model.score_lead({
        "company_size": 300,
        "email_opens": 7,
        "page_visits": 18,
        "content_downloads": 4,
        "engagement_velocity": 0.85,
        "intent_score": 2,
    })

    assert 0 <= result.score <= 100
    assert isinstance(result.is_sql, bool)
