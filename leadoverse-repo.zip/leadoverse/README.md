# Leadoverse — AI-Powered Multi-Channel Lead Scoring & Management Platform

Leadoverse is an AI-driven lead management system that ingests leads from multiple
channels, scores them with a hybrid machine learning classifier, detects buying
intent from text, removes duplicates, and syncs qualified leads to a CRM in
real time.

This repository contains the reference implementation of the architecture
described in our published paper:

> **Gore, A. N., Kolhe, R. V., Gaikwad, S. S., & Phate, S.** (2026).
> *Leadoverse: An AI-Powered Multi-Channel Lead Scoring and Management Platform.*
> International Journal of Scientific Research & Engineering Trends (IJSRET),
> 12(3). ISSN: 2395-566X.

## Why this exists

Traditional lead management relies on manual entry and fragmented,
channel-by-channel tracking. Leadoverse unifies lead capture across web forms,
social APIs, email, and REST integrations, then applies a weighted ensemble of
models to prioritize the leads most likely to convert — instead of leaving
that judgment call to whoever happens to look at the CRM next.

## How it works

```
Lead Input (web / social / email / API)
        │
        ▼
API Gateway & Normalization
        │
        ▼
Deduplication Engine  ──────────────►  merges duplicate records
        │                              (fuzzy match on name + exact
        ▼                               match on email/phone)
NLP Intent Classification (BERT)
        │
        ▼
XGBoost Lead Scoring (0–100)
        │
        ▼
CRM Sync & Sales Assignment ─────────►  Salesforce / HubSpot / Zoho
                                         (pushed when score ≥ 70)
```

**Lead scoring.** An XGBoost classifier combines demographic fit, firmographic
data, behavioral signals (page visits, content downloads, email opens), and the
intent classification output into a single 0–100 quality score. Leads scoring
70+ are flagged as Sales Qualified Leads (SQLs).

**Intent detection.** A BERT model fine-tuned on lead interaction text
classifies buying intent as High, Medium, or Low, feeding into the overall
score.

**Deduplication.** Levenshtein distance handles fuzzy name matching, combined
with exact matching on email and phone, to compute a composite similarity
score. Records above the similarity threshold are merged.

**CRM sync.** Qualified leads are pushed to connected CRMs with bidirectional
real-time sync, so sales teams always see current lead status without manual
re-entry.

## Reported results (from the paper)

| Metric | Value |
|---|---|
| F1 Score | 0.87 |
| AUC-ROC | 0.93 |
| Lead response time reduction | 89% |
| Conversion rate improvement | 79% |
| Avg. processing time per lead | 35ms |

## Project structure

```
leadoverse/
├── src/
│   ├── lead_scoring.py       # XGBoost scoring model
│   ├── intent_detection.py   # BERT-based intent classifier
│   ├── deduplication.py      # Fuzzy + exact match dedup engine
│   ├── crm_sync.py           # CRM integration adapters
│   ├── pipeline.py           # Hybrid classifier that ties it together
│   ├── schemas.py            # Pydantic request/response models
│   └── api.py                # FastAPI application
├── scripts/
│   └── train_model.py        # Trains the XGBoost scoring model
├── data/
│   └── sample_leads.csv      # Synthetic sample data for local testing
├── tests/
│   ├── test_deduplication.py
│   └── test_lead_scoring.py
├── docs/
│   └── architecture.md
├── requirements.txt
└── README.md
```

## Getting started

```bash
git clone https://github.com/atharvgore/leadoverse.git
cd leadoverse
pip install -r requirements.txt

# Train the scoring model on the sample dataset
python scripts/train_model.py

# Run the API locally
uvicorn src.api:app --reload
```

Then hit `POST /score-lead` with a lead payload to get back an intent
classification, similarity flag, and final score.

## Tech stack

Python, FastAPI, XGBoost, Hugging Face Transformers (BERT), scikit-learn,
pandas, Pydantic.

## Status

This is a reference implementation built to accompany the published paper.
It's structured for extension — swap in real CRM credentials in
`crm_sync.py`, point `train_model.py` at production lead data, and it's
ready to run against a live pipeline.

## Authors

Atharv Nitin Gore, Rushikesh Vijay Kolhe, Samarth Suresh Gaikwad —
AI & Data Science Engineering, Parvatibai Genba Moze College of Engineering.
Guided by Prof. Snehal Phate.

## License

MIT
