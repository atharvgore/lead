# Architecture

## Overview

Leadoverse consolidates lead signal from multiple independent modules into a
single quality score, rather than relying on any one heuristic. This document
summarizes how those modules fit together; see the published paper for full
methodology and evaluation details.

## Modules

**API Gateway** — normalizes incoming leads from web forms, social APIs
(LinkedIn, Facebook), email campaigns, and third-party REST integrations into
a single internal schema.

**Deduplication Engine** (`src/deduplication.py`) — computes a composite
similarity score across name (fuzzy match), email (exact), and phone (exact),
merging records above the similarity threshold before they reach scoring. This
prevents inflated pipeline counts and skewed conversion-rate reporting.

**Intent Classification** (`src/intent_detection.py`) — classifies the buying
intent behind a lead's interaction text (form messages, chat transcripts) as
High, Medium, or Low. This feeds directly into the scoring model as a feature
rather than being reported separately, since intent alone is a weak signal
without behavioral and firmographic context.

**Lead Scoring** (`src/lead_scoring.py`) — an XGBoost classifier trained on
historical conversion outcomes, combining demographic fit, company size,
behavioral signals, and intent classification into a single 0–100 score.
Leads at or above 70 are flagged as Sales Qualified Leads (SQL).

**CRM Sync** (`src/crm_sync.py`) — pushes SQLs to the connected CRM
(Salesforce, HubSpot, or Zoho) via adapter classes that share a common
interface, so switching CRMs doesn't require touching the scoring pipeline.

## Data flow

See the diagram in the main README. The key design decision is that
deduplication happens *before* scoring — scoring a duplicate record wastes
compute and risks double-counting a lead's engagement signals across two
records, which would artificially inflate its score.

## Extending this repo

- Swap the intent detector's base model for one fine-tuned on your own
  labeled lead-interaction data instead of generic sentiment analysis.
- Add authentication (JWT, as described in the paper) to `src/api.py` before
  exposing this outside a trusted network.
- Replace the CRM adapter stubs with real API calls once you have
  credentials for Salesforce, HubSpot, or Zoho.
